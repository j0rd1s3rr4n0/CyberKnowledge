
import os
import psutil
import logging

logging.basicConfig(filename="sysmon_monitor.log", level=logging.INFO)

def detect_suspicious_processes():
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmd = ' '.join(proc.info['cmdline'])
            if "-enc" in cmd and "powershell" in proc.info['name'].lower():
                logging.warning(f"[!] PowerShell sospechoso detectado: PID {proc.info['pid']} - CMD: {cmd}")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

detect_suspicious_processes()

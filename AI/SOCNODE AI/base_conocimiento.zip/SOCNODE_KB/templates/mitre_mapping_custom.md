
# Mapeo Personalizado - MITRE ATT&CK

## Incidente Analizado
- Técnica: T1059.001 - PowerShell
- Táctica: Execution
- IOC Clave: Uso de "-enc" en línea de comandos

## Otras Técnicas Posibles
- T1566.001 (Phishing vía Email)
- T1204 (User Execution)
- T1055 (Process Injection)

## Herramientas
- MISP
- ATT&CK Navigator
- Elastic Security

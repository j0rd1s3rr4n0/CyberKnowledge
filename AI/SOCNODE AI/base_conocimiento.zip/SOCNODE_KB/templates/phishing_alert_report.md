
# Reporte de Alerta: Phishing

## 📨 Correo Sospechoso
- Remitente: attacker@falsaempresa.com
- Asunto: Factura urgente
- Adjuntos: factura_2025.zip

## 🔍 Análisis Rápido
- Hash del archivo: [SHA256]
- Tipo de archivo: ZIP -> EXE
- Heurísticas sospechosas detectadas: ✅

## 🚫 Acción Recomendada
- Bloquear remitente en M365
- Eliminar correo en buzones afectados
- Aislar dispositivos si ejecutado

## 📝 Nota
Phishing dirigido. Similitudes con campaña APT de febrero 2025.

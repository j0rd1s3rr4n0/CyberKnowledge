
# Informe Técnico - Incidente de Seguridad

## 🆔 Identificación
- ID de Incidente: INC-2025-XXX
- Fecha detección: YYYY-MM-DD
- Detectado por: [SIEM/Humano]

## 📋 Resumen del Incidente
- Descripción breve: Se ha detectado un uso anómalo de PowerShell codificado en base64 en un sistema Windows Server.

## 🔍 Análisis Técnico
- Hash proceso: [SHA256]
- Usuario afectado: [usuario]
- Máquina: [hostname]
- IOC relevantes: -enc, base64, dominio externo sospechoso

## 🛡️ Contención
- Aislamiento del host ✅
- Revocación de credenciales ✅

## 📘 Lecciones Aprendidas
- Fortalecer detección en EDR
- Bloquear PowerShell sin firmar
